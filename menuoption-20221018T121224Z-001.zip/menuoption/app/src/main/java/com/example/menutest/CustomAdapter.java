package com.example.menutest;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.myViewHolder> {
    private Context context;
    private ArrayList hospital_id, hospital_name, hospital_location;

    CustomAdapter(Context context, ArrayList hospital_id, ArrayList hospital_name, ArrayList hospital_location){
        this.context=context;
        this.hospital_id=hospital_id;
        this.hospital_name=hospital_name;
        this.hospital_location=hospital_location;
    }

    @NonNull
    @Override
    public myViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater= LayoutInflater.from(context);
        View view=inflater.inflate(R.layout.card_demo2,parent,false);

        return new myViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myViewHolder holder, int position) {
        holder.hospital_id_txt.setText(String.valueOf(hospital_id.get(position)));
        holder.hospital_name_txt.setText(String.valueOf(hospital_name.get(position)));
        holder.hospital_location_txt.setText(String.valueOf(hospital_location.get(position)));
    }

    @Override
    public int getItemCount() {
        return hospital_id.size();
    }

    public class myViewHolder extends RecyclerView.ViewHolder {
        TextView hospital_id_txt, hospital_name_txt, hospital_location_txt;
        public myViewHolder(@NonNull View itemView) {
            super(itemView);
            hospital_id_txt=itemView.findViewById(R.id.hospital_id);
            hospital_name_txt=itemView.findViewById(R.id.hospital_name);
            hospital_location_txt=itemView.findViewById(R.id.hospital_location);

        }
    }
}
