package com.example.menutest;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

public class MyAdapter extends RecyclerView.Adapter<MyAdapter.myview_holder> {
    String data1[];
    int my_image[];
    Context context;

    public MyAdapter(Context ct, String s1[], int image[]){
        context=ct;
        data1=s1;
        my_image=image;
    }

    @NonNull
    @Override
    public myview_holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater=LayoutInflater.from(context);
        View view= inflater.inflate(R.layout.card_demo, parent,false);
        return new myview_holder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull myview_holder holder, final int position) {
        holder.t1.setText(data1[position]);
        holder.img1.setImageResource(my_image[position]);

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(context , Show_hospital.class);
                context.startActivity(i);
            }
        });
    }

    @Override
    public int getItemCount() {
        return my_image.length;
    }

    class myview_holder extends RecyclerView.ViewHolder {

        TextView t1;
        ImageView img1;
        ConstraintLayout constraintLayout;
        public myview_holder(@NonNull View itemView) {
            super(itemView);

            t1=itemView.findViewById(R.id.card_textview);
            img1=itemView.findViewById(R.id.card_img_view);
            constraintLayout=itemView.findViewById(R.id.Home_layout);
        }
    }
}
