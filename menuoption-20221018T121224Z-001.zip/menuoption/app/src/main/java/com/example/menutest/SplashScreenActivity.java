package com.example.menutest;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class SplashScreenActivity extends AppCompatActivity {

    ImageView logo;
    TextView sublogo;
    Animation top,bottom;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.splash_screen);

        logo = findViewById(R.id.logo);
        sublogo = findViewById(R.id.sublogo);

        top = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.logo);
        bottom = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.sublogo);

        logo.setAnimation(top);
        sublogo.setAnimation(bottom);

        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {

                startActivity(new Intent(getApplicationContext(),MainActivity.class));
                finish();
            }
        },2000);

    }
}