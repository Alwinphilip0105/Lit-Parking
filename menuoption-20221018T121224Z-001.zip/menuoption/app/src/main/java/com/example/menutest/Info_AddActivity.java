package com.example.menutest;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class Info_AddActivity extends AppCompatActivity {
    EditText hospital_name_in, hospital_location_in;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_add);

        hospital_name_in=findViewById(R.id.hospital_name1);
        hospital_location_in=findViewById(R.id.hospital_location1);
        button=findViewById(R.id.add_btn2);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                MyDatabaseHelper myDB=new MyDatabaseHelper(Info_AddActivity.this);
                myDB.add_hospital(hospital_name_in.getText().toString().trim(),
                        hospital_location_in.getText().toString().trim());
            }
        });

    }
}