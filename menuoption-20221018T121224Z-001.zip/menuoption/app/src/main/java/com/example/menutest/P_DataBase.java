package com.example.menutest;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import androidx.annotation.Nullable;

public class P_DataBase extends SQLiteOpenHelper {
    private Context context;
    private static final String DATABASE_NAME="Patient.db";
    private static final int Database_version=1;
    private static final String TABLE_NAME="Patient_info";
    private static final String COLUMN_ID="_ID";
    private static final String COLUMN_NAME="NAME";
    private static final String COLUMN_AGE="AGE";

    public P_DataBase(@Nullable Context context) {
        super(context, DATABASE_NAME, null, Database_version);
        this.context=context;
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query =
                "CREATE TABLE "+ TABLE_NAME+" (" + COLUMN_NAME + " TEXT, " +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                        +COLUMN_AGE + " INTEGER);";
        db.execSQL(query);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS "+TABLE_NAME);
    }
    void add_patient(int age, String name){

        SQLiteDatabase p_DB= this.getWritableDatabase();
        ContentValues cv= new ContentValues();

        cv.put(COLUMN_AGE,age);
        //cv.put(COLUMN_ID,id);
        cv.put(COLUMN_NAME,name);

        long result= p_DB.insert(TABLE_NAME,null, cv);

        if(result==-1)
            Toast.makeText(context, "failed", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(context, "added successfully", Toast.LENGTH_SHORT).show();
    }
    Cursor readAllData(){
        String query =" SELECT* FROM "+TABLE_NAME;
        SQLiteDatabase db= this.getReadableDatabase();

        Cursor cursor=null;

        if(db!=null){
            cursor=db.rawQuery(query,null);
        }
        return cursor;
    }
}
