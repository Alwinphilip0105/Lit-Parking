package com.example.menutest;

import android.database.Cursor;
import android.os.Bundle;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class Show_hospital extends AppCompatActivity {
    RecyclerView recyclerView;
    MyDatabaseHelper myDB;
    ArrayList<String> hospital_id, hospital_name,hospital_location;

    CustomAdapter customAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_show_hospital);

        recyclerView=findViewById(R.id.rv_show);

        myDB=new MyDatabaseHelper(Show_hospital.this);
        hospital_id=new ArrayList<>();
        hospital_location=new ArrayList<>();
        hospital_name=new ArrayList<>();

        storedatainarray();

        customAdapter=new CustomAdapter(Show_hospital.this,hospital_id,hospital_name,hospital_location);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(Show_hospital.this));
    }
    void storedatainarray(){
        Cursor cursor= myDB.readAllData();
        if(cursor.getCount()==0)
            Toast.makeText(this, "no data.", Toast.LENGTH_SHORT).show();
        else{
            while (cursor.moveToNext())
            {
                hospital_id.add(cursor.getString(0));
                hospital_name.add(cursor.getString(1));
                hospital_location.add(cursor.getString(2));
            }
        }
    }
}