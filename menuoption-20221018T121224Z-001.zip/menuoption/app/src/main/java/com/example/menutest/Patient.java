package com.example.menutest;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Patient extends AppCompatActivity {
    EditText p_name,p_id,p_age;
    TextView show_hash;
    Button enter_info,get_hash;
    private ArrayList patient_id, patient_name, patient_age;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient);

        p_name=findViewById(R.id.p_name);
        p_id=findViewById(R.id.p_id);
        p_age=findViewById(R.id.p_age);

        enter_info=findViewById(R.id.add_pdetails);
        enter_info.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                P_DataBase p_dataBase=new P_DataBase(Patient.this);
                p_dataBase.add_patient(Integer.valueOf(p_age.getText().toString().trim()),
                            p_name.getText().toString().trim());
            }
        });

        patient_name=new ArrayList<>();
        patient_age=new ArrayList<>();
        storedatainarray();

        show_hash=findViewById(R.id.hash_output);
        get_hash=findViewById(R.id.get_hash);
        get_hash.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String hash;
                Blockchain block1=new Blockchain(patient_name.toString(),patient_age.toString(),"0");
                hash=block1.calculateHash();
               show_hash.setText(hash);
            }
        });

    }
    void storedatainarray(){
        P_DataBase p_dataBase=new P_DataBase(Patient.this);
        Cursor cursor= p_dataBase.readAllData();
        if(cursor.getCount()==0)
            Toast.makeText(this, "no data.", Toast.LENGTH_SHORT).show();
        else{
            while (cursor.moveToNext())
            {
                patient_age.add(cursor.getString(0));
                patient_name.add(cursor.getString(1));
            }
        }
    }

}