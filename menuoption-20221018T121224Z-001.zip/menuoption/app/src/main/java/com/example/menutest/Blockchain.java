package com.example.menutest;
import java.security.MessageDigest;
import java.util.ArrayList;

public class Blockchain {
    public String hash;
    public String previousHash;
    private String name; //our data will be a simple message.
    private String patient_id;
    private String age;

    public String calculateHash() {
        String calculatedhash = StringUtil.applySha256(
                previousHash + name + age + patient_id
        );
        return calculatedhash;
    }
    //Block Constructor.
    public Blockchain(String name,String age, String previousHash, String patient_id) {
        this.name = name;
        this.patient_id=patient_id;
        this.previousHash = previousHash;
        this.age=age;
    }
}
class StringUtil {
    //Applies Sha256 to a string and returns the result.
    public static String applySha256(String input){
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            //Applies sha256 to our input,
            byte[] hash = digest.digest(input.getBytes("UTF-8"));
            StringBuffer hexString = new StringBuffer(); // This will contain hash as hexidecimal
            for (int i = 0; i < hash.length; i++) {
                String hex = Integer.toHexString(0xff & hash[i]);
                if(hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            return hexString.toString();
        }
        catch(Exception e) {
            throw new RuntimeException(e);
        }
    }
}

/*public class Blockchain {
    public static void main(String[] args) {
        Block genesisBlock = new Block("dave","69UI1278","42", "0");
        System.out.println("Hash for block 1 : " + genesisBlock.hash);
    }
}*/



