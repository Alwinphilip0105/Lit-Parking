package com.example.menutest;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import android.widget.Toolbar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class HomeActivity extends AppCompatActivity {
    RecyclerView recyclerView;
    Button btn1;
    androidx.appcompat.widget.Toolbar toolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.home);
        recyclerView=findViewById(R.id.recycler_view);
        btn1=findViewById(R.id.add_hospital_button);
        toolbar = findViewById(R.id.toolbar);

        toolbar.setOnMenuItemClickListener(new androidx.appcompat.widget.Toolbar.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem item) {
                switch (item.getItemId()){

                    case R.id.add_patient:
                        Intent intent = new Intent(HomeActivity.this,Patient.class);
                        startActivity(intent);
                        return true;
                    case R.id.add_hospital:
                        Intent i=new Intent(HomeActivity.this,Info_AddActivity.class);
                        startActivity(i);
                        return true;
                    case R.id.signout_btn_menu:
                        Toast.makeText(HomeActivity.this, "Signout failed", Toast.LENGTH_SHORT).show();
                }

                return true;
            }
        });

        String s1[];
        int images[]={R.drawable.heart_foreground,R.drawable.eyes1,R.drawable.blood_drop,R.drawable.liver1,R.drawable.lungs1,R.drawable.kidneybeans};
        s1=getResources().getStringArray(R.array.organs);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i=new Intent(HomeActivity.this,Info_AddActivity.class);
                startActivity(i);

            }
        });

        MyAdapter myAdapter = new  MyAdapter(this,s1,images);
        recyclerView.setAdapter(myAdapter);
        GridLayoutManager gridLayoutManager=new GridLayoutManager(this, 2, LinearLayoutManager .VERTICAL, false);
        recyclerView.setLayoutManager(gridLayoutManager);
    }




  /*  public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater=getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

             switch (item.getItemId()){
            case R.id.adduser:
                Intent intent = new Intent(HomeActivity.this,Info_AddActivity.class);
                startActivity(intent);

            case R.id.addcontact:
                Intent i=new Intent(this,Info_AddActivity.class);
                startActivity(i);
                return true;
            case R.id.addlocation:
                Toast.makeText(this, "user", Toast.LENGTH_SHORT).show();

        }
        return super.onOptionsItemSelected(item);
    }
*/

}